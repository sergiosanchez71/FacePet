Canted Comic
Font by Nils Cordes

This work is licensed under the Creative Commons Attribution-ShareAlike 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by-sa/4.0/.

You are free:

to Share � to copy, distribute and transmit the work
to Remix � to adapt the work

Under the following conditions:

Attribution. You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work).

Share Alike. If you alter, transform, or build upon this work, you may distribute the resulting work only under the same, similar or a compatible license.

For any reuse or distribution, you must make clear to others the license terms of this work. The best way to do this is with a link to this web page.

Any of the above conditions can be waived if you get permission from the copyright holder.
Nothing in this license impairs or restricts the author�s moral rights.

---
Disclaimer:
The font software is provided �as is�, without warranty of any kind, express or implied, including but not limited to any warranties of merchantability, fitness for a particular purpose and noninfringement of copyright, patent, trademark, or other right. In no event shall the copyright holder be liable for any claim, damages or other liability, including any general, special, indirect, incidental, or consequential damages, whether in an action of contract, tort or otherwise, arising from, out of the use or inability to use the font software or from other dealings in the font software.